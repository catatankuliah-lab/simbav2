<?php

namespace App\Controllers\Gudang;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        return 'Public Home';
    }
}
