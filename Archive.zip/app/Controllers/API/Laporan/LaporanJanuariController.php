<?php

namespace App\Controllers\API\Laporan;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class LaporanJanuariController extends BaseController
{
    public function index()
    {
        //
    }
}
