<?php

namespace App\Controllers\Bulog;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        return 'Public Bulog';
    }
}
