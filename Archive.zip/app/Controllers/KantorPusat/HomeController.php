<?php

namespace App\Controllers\KantorPusat;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        return 'Public Kantor Pusat';
    }
}
