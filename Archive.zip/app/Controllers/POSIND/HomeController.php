<?php

namespace App\Controllers\POSIND;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        return 'Public POSIND';
    }
}
