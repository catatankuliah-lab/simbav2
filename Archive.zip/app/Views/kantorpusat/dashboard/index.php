<?php $this->extend('kantorpusat/layout') ?>
<?php $this->section('content') ?>
<?php $this->endSection() ?>